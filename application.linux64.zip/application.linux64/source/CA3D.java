import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import peasy.test.*; 
import peasy.org.apache.commons.math.*; 
import peasy.*; 
import peasy.org.apache.commons.math.geometry.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class CA3D extends PApplet {





boolean go=true;
boolean shouldStop=true;
int cellSize=5;
PeasyCam camera;
static int matrixSize=50;
static int neighbour = 3;
int fr = 15; //Frames

public void setup(){
  //setting up some initial things
  size(400,400,P3D);
  camera = new PeasyCam(this, 500);
  camera.lookAt(125, 125, 0);
  CellMatrix.falseMatrix();
  CellMatrix.matrix[matrixSize/2][matrixSize/2][matrixSize/2]=1;
  frameRate(fr);
  lights();
  background(0);
}
public void draw(){
background(0);
//Now we draw every single cell
    for(int x = 0; x<CellMatrix.matrixX; x++){
        for(int y = 0; y<CellMatrix.matrixY; y++){
          for(int z = 0; z<CellMatrix.matrixZ; z++){
            if(CellMatrix.matrix[x][y][z]>0 && CellMatrix.matrix[x][y][z]<neighbour){
              pushMatrix();
              stroke(0xff000000,20);
              //setting some values for the colors
              int colorValue = matrixSize*3/2 - (abs(matrixSize/2-x)+abs(matrixSize/2-y)+abs(matrixSize/2-z));
              //Drawing the squares
              fill(255-colorValue*255/75,255-colorValue*255/75,255-colorValue*255/75);//Color
              translate(x*cellSize, y*cellSize, z*cellSize);//Position
              box(cellSize);//Form
              popMatrix();
            }
          }
        }
      }
  if(go){   
    CellMatrix.iterate();
    if (shouldStop)go=false;
  }
  
}

/**
*  This class sets the 3dimensional boolean matrix from which we obtain the information
*  regarding the position of the active cells.
*/
static class CellMatrix{
  public static int matrixX=matrixSize,matrixY=matrixSize,matrixZ=matrixSize;
  public static int[][][] matrix = new int[matrixX][matrixY][matrixZ];  
  public static int[][][] nextMatrix = new int[matrixX][matrixY][matrixZ]; 
  
  /**
  *  Sets every cell in the matrix to False
  */
  public static void falseMatrix(){
    for(int x = 0; x<matrixX; x++){
      for(int y = 0; y<matrixY; y++){
        for(int z = 0; z<matrixZ; z++){
          CellMatrix.matrix[x][y][z] = 0;
        }
      }
    }
  }
  
  /**
  *  Updates every cell
  */
  public static void iterate(){
    int counter;
    for(int x = 0; x<matrixX; x++){
      for(int y = 0; y<matrixY; y++){
        for(int z = 0; z<matrixZ; z++){//For each cell in the matrix
          if (CellMatrix.matrix[x][y][z]>0 && CellMatrix.matrix[x][y][z]<neighbour){//If it is active
            for(int i = -1; i<2; i++){
              for(int j = -1; j<2; j++){
                for(int k = -1; k<2; k++){//For each of it's neighbours 
                    
                  //Tell 'em it's active!
                    if(!(i==0 && j==0 && k==0)){//if the neighbour is not the cell
                    int newX=x,newY=y,newZ=z;//these new values are just to avoid indexOutOfRange errors
                      if(x+i==matrixX)newX=-1;
                      if(y+j==matrixY)newY=-1;
                      if(z+k==matrixZ)newZ=-1;
                      if(x+i==-1)newX=matrixX;
                      if(y+j==-1)newY=matrixY;
                      if(z+k==-1)newZ=matrixZ;
                      CellMatrix.nextMatrix[newX+i][newY+j][newZ+k]++; //++ it's "neighbours", that is their value
                    }
                  
                }
              }
            }
          }

        }
      }
    }
    CellMatrix.matrix = CellMatrix.nextMatrix;//We update the real matrix with the nextMatrix
    CellMatrix.nextMatrix = new int[matrixX][matrixY][matrixZ]; //and reset the nextMatrix
  }
    
}







public void keyPressed(){
if (key == 'p') {//PAUSE
  go=false;
  shouldStop=true;
  }
else if (key == 'g') {//GO!
  go=true;
  shouldStop=false;
  }
else if (key == 's') {//STEP
  go=true;
  shouldStop=true;
  }
  else if (key == 'r') {//RESET
    camera = new PeasyCam(this, 500);
    camera.lookAt(125, 125, 0);
    CellMatrix.falseMatrix();
  CellMatrix.matrix[matrixSize/2][matrixSize/2][matrixSize/2]=1;
  go=true;
  shouldStop=true;
  }
  
  else if (key == '1') {
   neighbour=2;
  }
  else if (key == '2') {
   neighbour=3;
  }
  else if (key == '3') {
   neighbour=4;
  }
  else if (key == '4') {
   neighbour=5;
  }
  else if (key == '5') {
   neighbour=6;
  }
  else if (key == '6') {
   neighbour=7;
  }
  else if (key == '7') {
   neighbour=8;
  }
  else if (key == '8') {
   neighbour=9;
  }
  else if (key == '9') {
   neighbour=10;
  }
  
  else if (key == '+') {
   fr++;
  }
  else if (key == '-') {
   if(fr>1)fr--;
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "CA3D" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
